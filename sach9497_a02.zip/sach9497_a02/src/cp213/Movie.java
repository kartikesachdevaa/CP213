package cp213;

import java.io.PrintStream;

/**
 * Movie class definition.
 *
 * @author Kartike Sachdeva, 169049497, sach9497@mylaurier.ca
 * @version 2024-09-01
 */
public class Movie implements Comparable<Movie> {

	// Constants
	/**
	 * The first year movies were produced.
	 */
	public static final int FIRST_YEAR = 1888;
	/**
	 * The names of movie genres.
	 */
	public static final String[] GENRES = { "science fiction", "fantasy", "drama", "romance", "comedy", "zombie",
			"action", "historical", "horror", "war", "mystery" };
	/**
	 * The maximum allowed Movie rating.
	 */
	public static final double MAX_RATING = 10.0;
	/**
	 * The minimum allowed Movie rating.
	 */
	public static final double MIN_RATING = 0.0;

	/**
	 * Creates a string of movie genres in the format:
	 *
	 * <pre>
	 0: science fiction
	 1: fantasy
	 2: drama
	...
	10: mystery
	 * </pre>
	 *
	 * @return A formatted numbered string of Movie genres.
	 */
	public static String genresMenu() {
		StringBuilder genres = new StringBuilder();
		for (int i = 0; i < GENRES.length; i++) {
			genres.append(i).append(":").append(GENRES[i]).append(System.lineSeparator());
		}
		return genres.toString();
	}

	// Attributes
	private String director = "";
	private int genre = -1;
	private double rating = 0;
	private String title = "";
	private int year = 0;

	/**
	 * Instantiates a Movie object.
	 *
	 * @param title    Movie title.
	 * @param year     Year of release.
	 * @param director Name of director.
	 * @param rating   Rating of 1 - 10 from IMDB.
	 * @param genre    Number representing Movie genre.
	 */
	public Movie(final String title, final int year, final String director, final double rating, final int genre) {

		this.title = title != null ? title : "";
		this.year = year > 0 ? year : 0;
		this.director = director != null ? director : "";
		this.rating = rating >= MIN_RATING && rating <= MAX_RATING ? rating : 0;
		this.genre = genre >= 0 && genre < GENRES.length ? genre : -1;

		return;
	}

	/**
	 * Movies are compared by title, then by year if the titles match. Must ignore
	 * case. Ex: Zulu, 1964 precedes Zulu, 2013. Returns:
	 * <ul>
	 * <li>0 if this equals target</li>
	 * <li>&lt; 0 if this precedes target</li>
	 * <li>&gt; 0 if this follows target</li>
	 * </ul>
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(final Movie target) {

		int result = title.compareToIgnoreCase(target.title);
		if (result == 0) {
			result = Integer.compare(year, target.year);
		}

		return result;
	}

	/**
	 * Converts a genre integer to a string.
	 *
	 * @return The string version of the genre number.
	 */
	public String genreToName() {
		String g2n = " ";
		if (genre >= 0 && genre < GENRES.length) {
			g2n += GENRES[genre];
		}

		return g2n;
	}

	/**
	 * Director getter.
	 *
	 * @return The director.
	 */
	public String getDirector() {

		return director;
	}

	/**
	 * Genre getter.
	 *
	 * @return The genre number.
	 */
	public int getGenre() {

		return genre;
	}

	/**
	 * Rating getter.
	 *
	 * @return The rating.
	 */
	public double getRating() {

		return rating;
	}

	/**
	 * Title getter.
	 *
	 * @return The title.
	 */
	public String getTitle() {

		return title;
	}

	/**
	 * Year getter.
	 *
	 * @return The year.
	 */
	public int getYear() {

		return year;
	}

	/**
	 * Creates a formatted string of Movie key data in the format "title, year". Ex:
	 * "Zulu, 1964".
	 *
	 * @return A Movie key as a string.
	 */
	public String key() {
		StringBuilder sb = new StringBuilder();
		sb.append(title).append(", ").append(year).append(", ").append(director).append(", ").append(rating)
				.append(", ").append(genre);
		return sb.toString();
	}

	/**
	 * Rating setter.
	 *
	 * @param rating The new rating.
	 */
	public void setRating(final double rating) {

		this.rating = rating;

	}

	/**
	 * Returns a string in the format:
	 *
	 * <pre>
	Title:    title
	Year:     year
	Director: director
	Rating:   rating
	Genre:    genre
	 * </pre>
	 *
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString() Creates a formatted string of movie data.
	 */
	@Override
	public String toString() {

		return "Title: " + title + "\n" + "Year: " + year + "\n" + "Director: " + director + "\n" + "Rating: " + rating
				+ "\n" + "Genre: " + genre;
	}

	/**
	 * Writes a single line of movie data to an open PrintStream in the format:
	 * title|year|director|rating|genre
	 *
	 * @param ps Output PrintStream.
	 */
	public void write(final PrintStream ps) {

		ps.println(title + "|" + year + "|" + director + "|" + rating + "|" + genre);

		return;
	}

}
