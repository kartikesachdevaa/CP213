package cp213;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Utilities for working with Movie objects.
 *
 * @author Kartike Sachdeva, 169049497, sach9497@mylaurier.ca
 * @version 2024-09-01
 */
public class MovieUtilities {

	/**
	 * Counts the number of movies in each genre given in Movie.GENRES. An empty
	 * movies list should produce a count array of: [0,0,0,0,0,0,0,0,0,0,0]
	 *
	 * @param movies List of movies.
	 * @return Number of genres across all Movies. One entry for each genre in the
	 *         Movie.GENRES array.
	 * 
	 */
	public static int[] genreCounts(final ArrayList<Movie> movies) {

		int[] count = new int[Movie.GENRES.length];

		for (Movie movie : movies) {
			int Indexgenre = movie.getGenre();
			if (Indexgenre >= 0 && Indexgenre < Movie.GENRES.length) {
				count[Indexgenre]++;
			}
		}

		return count;
	}

	/**
	 * Creates a Movie object by requesting data from a user. Uses the format:
	 *
	 * <pre>
	Title:
	Year:
	Director:
	Rating:
	Genres:
	0: science fiction
	1: fantasy
	...
	10: mystery
	
	Enter a genre number:
	 * </pre>
	 *
	 * @param keyboard A keyboard (System.in) Scanner.
	 * @return A Movie object.
	 */
	public static Movie getMovie(final Scanner keyboard) {
		System.out.println("Title:");
		String title = keyboard.nextLine();

		System.out.println("Year:");
		int year = keyboard.nextInt();
		keyboard.nextLine();

		System.out.println("Director:");
		String director = keyboard.nextLine();

		System.out.println("Ratings:");
		double rating = keyboard.nextDouble();
		keyboard.nextLine();

		System.out.println("Genre (0-" + (Movie.GENRES.length - 1) + "):");
		Movie.genresMenu();
		int genre = keyboard.nextInt();
		keyboard.nextLine();

		return new Movie(title, year, director, rating, genre);

	}

	/**
	 * Creates a list of Movies whose genre is equal to the genre parameter.
	 *
	 * @param movies List of movies.
	 * @param genre  Genre to compare against.
	 * @return List of movies of genre.
	 */
	public static ArrayList<Movie> getByGenre(final ArrayList<Movie> movies, final int genre) {

		ArrayList<Movie> movielist = new ArrayList<>();
		for (Movie movie : movies) {
			int Indexgenre = movie.getGenre();
			if (Indexgenre == genre) {
				movielist.add(movie);
			}
		}
		return movielist;
	}

	/**
	 * Creates a list of Movies whose ratings are equal to or higher than rating.
	 *
	 * @param movies List of movies.
	 * @param rating Rating to compare against.
	 * @return List of movies of rating or higher.
	 */
	public static ArrayList<Movie> getByRating(final ArrayList<Movie> movies, final double rating) {
		ArrayList<Movie> movielist = new ArrayList<>();
		for (Movie movie : movies) {
			if (movie.getRating() >= rating) {
				movielist.add(movie);
			}
		}
		return movielist;
	}

	/**
	 * Creates a list of Movies from a particular year.
	 *
	 * @param movies List of movies.
	 * @param year   Year to compare against.
	 * @return List of movies of year.
	 */
	public static ArrayList<Movie> getByYear(final ArrayList<Movie> movies, final int year) {

		ArrayList<Movie> movielist = new ArrayList<>();

		for (Movie movie : movies) {
			if (movie.getYear() == year) {
				movielist.add(movie);
			}
		}

		return movielist;
	}

	/**
	 * Asks a user to select a genre from a list of genres displayed by calling
	 * Movie.genresMenu() and returns an integer genre code. The genre must be a
	 * valid index to an item in Movie.GENRES.
	 *
	 * @param keyboard A keyboard (System.in) Scanner.
	 * @return An integer genre code.
	 */
	public static int readGenre(final Scanner keyboard) {
		System.out.println("Select a genre from the list of genres below:");
		Movie.genresMenu();
		int value = keyboard.nextInt();
		return value;
	}

	/**
	 * Creates and returns a Movie object from a line of formatted string data.
	 *
	 * @param line A vertical bar-delimited line of movie data in the format
	 *             title|year|director|rating|genre
	 * @return The data from line as a Movie object.
	 */
	public static Movie readMovie(final String line) {
		String[] sep = line.split("\\|");
		String title = sep[0];
		int year = Integer.parseInt(sep[1]);
		String director = sep[2];
		double rating = Double.parseDouble(sep[3]);
		int genre = Integer.parseInt(sep[4]);
		return new Movie(title, year, director, rating, genre);
	}

	/**
	 * Reads a list of Movies from a file.
	 *
	 * @param fileIn A Scanner of a Movie data file in the format
	 *               title|year|director|rating|genre
	 * @return A list of Movie objects.
	 */
	public static ArrayList<Movie> readMovies(final Scanner fileIn) {

		ArrayList<Movie> movielist = new ArrayList<>();

		while (fileIn.hasNextLine()) {
			String line = fileIn.nextLine();
			Movie movie = readMovie(line);
			movielist.add(movie);
		}

		return movielist;
	}

	/**
	 * Writes the contents of a list of Movie to a PrintStream.
	 *
	 * @param movies A list of Movie objects.
	 * @param ps     Output PrintStream.
	 */
	public static void writeMovies(final ArrayList<Movie> movies, PrintStream ps) {
		for (Movie movie : movies) {
			String line = String.format("%s|%d|%s|%.1f|%s", movie.getTitle(), movie.getYear(), movie.getDirector(),
					movie.getRating(), movie.getGenre());
			ps.println(line);
		}

		return;
	}

}
