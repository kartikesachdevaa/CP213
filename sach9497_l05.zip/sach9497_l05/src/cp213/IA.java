package cp213;

/**
 * Inherited class in simple example of inheritance / polymorphism.
 *
 * @author Kartike Sachdeva, 169049497, sach9497@mylaurier.ca
 * @version 2022-02-25
 */
public class IA extends Student {

	private String course = null;

	/**
	 * @param lastName   Instructional Assistant last name (surname): defined in
	 *                   Person
	 * @param firstName  Instructional Assistant first name (given name): defined in
	 *                   Person
	 * @param department Instructional Assistant id : defined in Student
	 * 
	 * @param course     Instructional Assistant course
	 */
	public IA(final String lastName, final String firstName, final String id, final String course) {
		super(lastName, firstName, id);
		this.course = course;
	}

	/**
	 * Getter for course.
	 *
	 * @return this.course
	 */
	public String getCourse() {
		return this.course;
	}

	/**
	 * Creates formatted string version of IA.
	 */
	@Override
	public String toString() {
		return (super.toString() + "\nCourse: " + this.course);
	}

}