package cp213;

/**
 * Inherited class in simple example of inheritance / polymorphism.
 *
 * @author Kartike Sachdeva, 169049497, sach9497@mylaurier.ca
 * @version 2022-02-25
 */
public class CAS extends Professor {

	private String term = null;

	/**
	 * @param lastName   Contract Academic Staff last name (surname): defined in
	 *                   Person
	 * @param firstName  Contract Academic Staff first name (given name): defined in
	 *                   Person
	 * @param department Contract Academic Staff department : defined in Professor
	 * 
	 * @param term       Contract Academic Staff term
	 */
	public CAS(final String lastName, final String firstName, final String department, final String term) {
		super(lastName, firstName, department);
		this.term = term;
	}

	/**
	 * Getter for Term.
	 *
	 * @return this.term
	 */
	public String getTerm() {
		return this.term;
	}

	/**
	 * Creates formatted string version of CAS.
	 */
	@Override
	public String toString() {
		return (super.toString() + "\nTerm: " + this.term);
	}

}
